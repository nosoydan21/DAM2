package org.example.controlador;

import org.example.dao.ConexionBD;
import org.example.modelo.*;


import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

public class Inventario {
    private Connection conexion;




    public Inventario() throws SQLException, IOException {
        ConexionBD conexionDAO=new ConexionBD();
        conexion= conexionDAO.getConexion();


    }
    /*

     */
    public boolean insertarProductoElectronico(Producto producto) throws SQLException {
        return false;
    }
    public boolean insertarProductoRopa(Producto producto) throws SQLException {
        return false;
    }
    /**
     *
     * @param producto
     * @return true si el inserta el producto en el invenario si el producto pasado cómo parametro el id no está en el inventario
     */
    public boolean insertarProducto(Producto producto) throws SQLException {
        if (producto instanceof Ropa){
            return insertarProductoRopa(producto);
        }
        else{

            return  insertarProductoElectronico(producto);
        }



    }

    public ArrayList<Producto> getListaProductos() throws SQLException {
        return null;
    }



    /**
     *
     * @param idProducto a vender
     * @param cantidad de producto a vender
     * @return true si realiza la venta porque hay suficente stock, devuelve false si no hay suficiente stock
      */
    public boolean venderProducto(int idProducto, int cantidad) throws SQLException {
       return false;


    }

    /**
     *
     * @param idProducto a reponer
     * @param cantidad de producto a reponer
     *
     */
    public boolean reponerProducto(int idProducto, int cantidad) throws SQLException {

        return true;


    }
}
